<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AlbumDelegate</name>
    <message>
        <location filename="../PhotoViewerCore/AlbumDelegate.qml" line="59"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>photoviewer</name>
    <message>
        <location filename="../photoviewer.qml" line="30"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../photoviewer.qml" line="39"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../photoviewer.qml" line="52"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
