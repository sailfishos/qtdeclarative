<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" sourcelanguage="en">
<context>
    <name>i18n</name>
    <message>
        <location filename="../i18n.qml" line="30"/>
        <source>Hello</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
