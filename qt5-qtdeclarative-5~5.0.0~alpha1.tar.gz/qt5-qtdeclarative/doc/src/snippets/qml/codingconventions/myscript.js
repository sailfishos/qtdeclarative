function calculateWidth(parent)
{
    if (parent == null)
        return 0

    var w = parent.width / 3
    // ...
    // more javascript code
    // ...
    console.debug(w)
    return w
}
